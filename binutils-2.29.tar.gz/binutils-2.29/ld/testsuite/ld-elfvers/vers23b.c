void
bar (void) 
{
}
