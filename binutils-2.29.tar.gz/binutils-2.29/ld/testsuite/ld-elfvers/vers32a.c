void foo(void) {}
