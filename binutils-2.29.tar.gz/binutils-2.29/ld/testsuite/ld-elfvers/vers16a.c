int show_bar ()
{
  return 1;
}
int show_foo ()
{
  return show_bar ();
}
