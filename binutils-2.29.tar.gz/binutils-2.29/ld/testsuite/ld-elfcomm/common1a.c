char foo1 [2] __attribute__((aligned(64)));
char foo2 [2] __attribute__((aligned(128)));
