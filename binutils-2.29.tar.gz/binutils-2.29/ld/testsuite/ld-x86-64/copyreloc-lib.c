int a_glob = 2;
