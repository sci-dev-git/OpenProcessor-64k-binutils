#include <stdio.h>

void
fun (void)
{
  printf ("Weak defined\n");
}
