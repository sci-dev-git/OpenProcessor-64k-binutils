int
func (void)
{
  return 0x12345678;
}
