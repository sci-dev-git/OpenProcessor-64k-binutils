#include <stdio.h>

void
foo2 (void)
{
  printf ("foo2\n");
}
