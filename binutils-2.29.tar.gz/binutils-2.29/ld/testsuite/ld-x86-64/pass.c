#include <stdio.h>

int
main ()
{
  printf ("PASS\n");
  return 0;
}
