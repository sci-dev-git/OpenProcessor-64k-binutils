void
f (void)
{
}
