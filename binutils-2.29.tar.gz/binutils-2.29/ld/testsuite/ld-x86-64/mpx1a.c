#include <stdio.h>

void
foo1 (void)
{
  printf ("foo1\n");
}
