extern void property (void);

int
main ()
{
  property ();
  return 0;
}
