. ${srcdir}/emulparams/elf32ppc.sh
. ${srcdir}/emulparams/elf_fbsd.sh

OUTPUT_FORMAT="elf32-powerpc-freebsd"

