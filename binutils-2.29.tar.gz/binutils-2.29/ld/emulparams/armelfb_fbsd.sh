. ${srcdir}/emulparams/armelf_fbsd.sh
OUTPUT_FORMAT="elf32-bigarm"
