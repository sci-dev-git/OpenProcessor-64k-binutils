. ${srcdir}/emulparams/arclinux.sh
# Extend the OTHER_SECTIONS for nps.
. ${srcdir}/emulparams/arc-nps.sh
