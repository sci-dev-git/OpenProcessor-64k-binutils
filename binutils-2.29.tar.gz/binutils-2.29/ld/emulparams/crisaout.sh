# This is for embedded products and elinux (no MMU) with a.out.
SCRIPT_NAME=crisaout
OUTPUT_FORMAT="a.out-cris"
TARGET_PAGE_SIZE=2
TEXT_START_ADDR=0
ARCH=cris
