. ${srcdir}/emulparams/shlelf32_linux.sh
OUTPUT_FORMAT="elf32-sh64big-linux"
