. ${srcdir}/emulparams/h8300elf_linux.sh
ARCH="h8300:h8300s"
STACK_ADDR=0x2fefc
