. ${srcdir}/emulparams/armelf_nacl.sh
OUTPUT_FORMAT="$BIG_OUTPUT_FORMAT"
