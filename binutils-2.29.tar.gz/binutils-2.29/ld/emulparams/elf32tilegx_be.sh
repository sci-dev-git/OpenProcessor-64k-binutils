. ${srcdir}/emulparams/elf32tilegx.sh
OUTPUT_FORMAT="elf32-tilegx-be"
