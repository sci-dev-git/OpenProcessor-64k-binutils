. ${srcdir}/emulparams/elf_k1om.sh
. ${srcdir}/emulparams/elf_fbsd.sh
OUTPUT_FORMAT="elf64-k1om-freebsd"
