EMBEDDED=yes
. ${srcdir}/emulparams/elf32bmip.sh
