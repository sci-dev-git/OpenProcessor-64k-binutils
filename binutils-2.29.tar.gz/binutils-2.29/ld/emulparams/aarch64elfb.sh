. ${srcdir}/emulparams/aarch64elf.sh
OUTPUT_FORMAT="elf64-bigaarch64"
