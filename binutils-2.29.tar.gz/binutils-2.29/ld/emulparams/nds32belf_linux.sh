. ${srcdir}/emulparams/nds32elf_linux.sh
OUTPUT_FORMAT="$BIG_OUTPUT_FORMAT"
