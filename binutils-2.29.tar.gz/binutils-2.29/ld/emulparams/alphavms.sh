SCRIPT_NAME=alphavms

OUTPUT_FORMAT="vms-alpha"
ARCH=alpha

COMPILE_IN=yes
EXTRA_EM_FILE=vms