. ${srcdir}/emulparams/elf64ppc.sh
. ${srcdir}/emulparams/elf_fbsd.sh

OUTPUT_FORMAT="elf64-powerpc-freebsd"
DEFAULT_PLT_STATIC_CHAIN=1

