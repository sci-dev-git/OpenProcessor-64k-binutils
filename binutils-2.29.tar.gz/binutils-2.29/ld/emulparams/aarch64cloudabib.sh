. ${srcdir}/emulparams/aarch64cloudabi.sh
OUTPUT_FORMAT="elf64-bigaarch64-cloudabi"
