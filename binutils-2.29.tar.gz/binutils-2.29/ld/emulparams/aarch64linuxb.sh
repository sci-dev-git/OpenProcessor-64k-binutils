. ${srcdir}/emulparams/aarch64linux.sh
OUTPUT_FORMAT="elf64-bigaarch64"
ELF_INTERPRETER_NAME=\"/lib/ld-linux-aarch64_be.so.1\"
