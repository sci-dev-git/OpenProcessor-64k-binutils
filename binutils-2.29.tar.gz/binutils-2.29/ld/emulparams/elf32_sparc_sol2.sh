. ${srcdir}/emulparams/elf32_sparc.sh
. ${srcdir}/emulparams/solaris2.sh
EXTRA_EM_FILE=solaris2
OUTPUT_FORMAT="elf32-sparc-sol2"
