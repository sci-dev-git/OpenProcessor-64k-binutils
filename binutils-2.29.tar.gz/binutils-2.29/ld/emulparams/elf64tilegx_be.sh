. ${srcdir}/emulparams/elf64tilegx.sh
OUTPUT_FORMAT="elf64-tilegx-be"
