. ${srcdir}/emulparams/shelf32_nbsd.sh

OUTPUT_FORMAT="elf32-sh64l-nbsd"
