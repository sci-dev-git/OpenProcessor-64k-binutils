. ${srcdir}/emulparams/elf64alpha.sh
. ${srcdir}/emulparams/elf_fbsd.sh
OUTPUT_FORMAT="elf64-alpha-freebsd"
