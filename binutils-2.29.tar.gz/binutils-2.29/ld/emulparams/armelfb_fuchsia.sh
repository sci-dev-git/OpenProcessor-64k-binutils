. ${srcdir}/emulparams/armelf_fuchsia.sh
OUTPUT_FORMAT="$BIG_OUTPUT_FORMAT"
