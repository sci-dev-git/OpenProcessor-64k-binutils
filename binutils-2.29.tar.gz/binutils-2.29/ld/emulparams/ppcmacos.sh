TEMPLATE_NAME=aix
SCRIPT_NAME=aix
OUTPUT_FORMAT="xcoff-powermac"
OUTPUT_FORMAT_32BIT="xcoff-powermac"
OUTPUT_FORMAT_64BIT="xcoff-powermac"
ARCH=powerpc
