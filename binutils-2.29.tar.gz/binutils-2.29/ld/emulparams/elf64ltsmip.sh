. ${srcdir}/emulparams/elf64btsmip.sh
OUTPUT_FORMAT="elf64-tradlittlemips"
BIG_OUTPUT_FORMAT="elf64-tradbigmips"
LITTLE_OUTPUT_FORMAT="elf64-tradlittlemips"
